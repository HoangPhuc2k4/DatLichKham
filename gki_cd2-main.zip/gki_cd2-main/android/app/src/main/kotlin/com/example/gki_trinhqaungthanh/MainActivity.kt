package com.example.gki_trinhqaungthanh

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
