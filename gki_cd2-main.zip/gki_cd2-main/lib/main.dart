import 'package:flutter/material.dart';
import 'guide_list_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FixIt Guide',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2FA3FA)),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const GuideListScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
