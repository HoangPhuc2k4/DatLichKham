class Guide {
  final String id;
  final String title;
  final String description;
  final String imagePath;
  final List<String> steps;
  final List<String> toolsRequired;

  Guide({
    required this.id,
    required this.title,
    required this.description,
    required this.imagePath,
    required this.steps,
    required this.toolsRequired,
  });
}

final List<Guide> defaultGuides = [
  Guide(
    id: '1',
    title: 'Thay bóng đèn hỏng',
    description: 'Hướng dẫn chi tiết cách thay bóng đèn tròn an toàn tại nhà chỉ với vài bước đơn giản.',
    imagePath: 'https://images.unsplash.com/photo-1550989460-0adf9ea622e2?auto=format&fit=crop&q=80&w=400',
    toolsRequired: ['Bóng đèn mới (cùng loại)', 'Ghế đẩu hoặc thang xếp', 'Găng tay cao su (tùy chọn)'],
    steps: [
      'Tắt công tắc điện của bóng đèn cần thay.',
      'Đợi bóng đèn cũ nguội hẳn (nếu vừa sử dụng).',
      'Đứng lên nền vững chắc, dùng tay vặn ngược chiều kim đồng hồ để tháo bóng đèn cũ.',
      'Lắp bóng đèn mới bằng cách vặn theo chiều kim đồng hồ cho đến khi chặt.',
      'Bật công tắc xem đèn đã sáng chưa.'
    ],
  ),
  Guide(
    id: '2',
    title: 'Sửa vòi nước rỉ nhỏ giọt',
    description: 'Khắc phục tình trạng vòi nước bị rò rỉ, nguyên nhân chủ yếu là do mòn gioăng cao su.',
    imagePath: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=400',
    toolsRequired: ['Cờ lê hoặc mỏ lết', 'Tua vít', 'Gioăng cao su thay thế', 'Băng tan', 'Giẻ lau'],
    steps: [
      'Khóa van nước tổng hoặc van nước dẫn vào vòi.',
      'Mở vòi nước để xả hết nước còn đọng bên trong.',
      'Dùng tua vít tháo ốc vít gắn trên tay vặn vòi nước.',
      'Dùng cờ lê thảo lỏng đai ốc bảo vệ và lấy ruột vòi ra ngoài.',
      'Kiểm tra gioăng cao su, tháo cái cũ và lắp gioăng cao su mới vào.',
      'Lắp lại các bộ phận theo thứ tự ngược lại và thử mở nước.'
    ],
  ),
  Guide(
    id: '3',
    title: 'Thông tắc bồn rửa chén',
    description: 'Cách xử lý bồn rửa chén bị tắc nghẽn do cặn bẩn, dầu mỡ tích tụ.',
    imagePath: 'https://images.unsplash.com/photo-1582269438759-3fb7ea3cb0bc?auto=format&fit=crop&q=80&w=400',
    toolsRequired: ['Baking soda', 'Giấm ăn', 'Nước sôi', 'Cây thông bồn cầu mini (tùy chọn)'],
    steps: [
      'Đổ 1/2 cốc baking soda xuống miệng ống thoát nước.',
      'Đổ tiếp 1 cốc giấm trắng xuống. Lúc này sẽ có hiện tượng sủi bọt.',
      'Bịt nắp bồn rửa lại khoảng 15-20 phút.',
      'Cuối cùng đổ trực tiếp 1 ấm nước sôi xuống để cuốn trôi cặn bẩn.',
      'Nếu vẫn tắc, bạn có thể tháo đường ống chữ U dưới bồn rửa để vệ sinh tay.'
    ],
  ),
];
